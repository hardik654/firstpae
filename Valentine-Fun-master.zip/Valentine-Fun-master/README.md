# Valentine-Fun
After getting inspired from a Instagram reel, I decided to create this "responsive" and "interactive" way to ask your crush out using HTML, CSS & Js. I ain't
got no girl but this valentine may be you can shoot your shot ;)


If you are unfamiliar with how to run HTML or CSS :
1. Download the repo and open in any code editor(or ignore other files just copy HTML code and CSS code and run it on your system)
2. Start live server 

*you can also directly fork my repo !

Or You can use it Directly by this link:(hosted link)
https://ujjawaltyagii.github.io/Valentine-Fun/
